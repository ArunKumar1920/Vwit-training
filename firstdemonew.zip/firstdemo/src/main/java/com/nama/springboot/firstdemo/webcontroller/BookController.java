package com.nama.springboot.firstdemo.webcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nama.springboot.firstdemo.dao.BookDao;
import com.nama.springboot.firstdemo.model.Book;

@Controller
public class BookController {
	
	@Autowired
	BookDao bookDao;
	
	@GetMapping("/getbook/{bookId}")
	public String getBookDetails(@PathVariable int bookId,ModelMap model) {
		Book b = bookDao.getBook(bookId);
		if(b!=null) {
			model.addAttribute("bookObj", b);
		}
		else {
			model.addAttribute("msg","book not found with id: "+bookId);
		}
		return "book";
	}
}
