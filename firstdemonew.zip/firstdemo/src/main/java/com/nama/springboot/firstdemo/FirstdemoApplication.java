package com.nama.springboot.firstdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.nama.springboot.firstdemo.model.Books;
import com.nama.springboot.firstdemo.model.Employee;
import com.nama.springboot.firstdemo.model.Helloworld;
//@SpringBootApplication = @Configuration + @ComponentScan + @AutoConfiguration
@SpringBootApplication
public class FirstdemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(FirstdemoApplication.class, args);
		
		Employee e= (Employee)context.getBean("emp");
		
		System.out.println(e.getEmpname());
		
		//Helloworld hw= (Helloworld)context.getBean("hello");
		
		//System.out.println(hw.getMessage());
		Books b=(Books)context.getBean("book");
		System.out.println(b.getName());
	}
	

}
