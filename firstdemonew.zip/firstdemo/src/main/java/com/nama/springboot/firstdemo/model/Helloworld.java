package com.nama.springboot.firstdemo.model;

public class Helloworld {
	
	private String message;

	public String getMessage() {
		return message;
	}
	
	public Helloworld() {
		
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Helloworld(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "Helloworld [message=" + message + "]";
	}
	

}
