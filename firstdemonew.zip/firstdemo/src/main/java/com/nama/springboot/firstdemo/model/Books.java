package com.nama.springboot.firstdemo.model;

public class Books {
	
	private int price;
	private String name;
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Books [price=" + price + ", name=" + name + "]";
	}
	public Books(int price, String name) {
		super();
		this.price = price;
		this.name = name;
	}
	
	
	

}
