package com.nama.springboot.firstdemo;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.nama.springboot.firstdemo.model.Books;
import com.nama.springboot.firstdemo.model.Employee;

@Component
@ConfigurationProperties("app")
public class AppConfigprop {
	
	private String message;
	private Employee emp;
	private Books book;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	
	public static class Employee{
		private String Ename;
		private int Empid;
		private double sal;
		private String Address;
		
		public String getEname() {
			return Ename;
		}
		public void setEname(String ename) {
			Ename = ename;
		}
		public int getEmpid() {
			return Empid;
		}
		public void setEmpid(int empid) {
			Empid = empid;
		}
		public double getSal() {
			return sal;
		}
		public void setSal(double sal) {
			this.sal = sal;
		}
		public String getAddress() {
			return Address;
		}
		public void setAddress(String address) {
			Address = address;
		}
		
	}

	public Books getBook() {
		return book;
	}

	public void setBook(Books book) {
		this.book = book;
	}
	 public static class Books{
		 private int price;
		 private String name;
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		 
	 }
	
	

}
