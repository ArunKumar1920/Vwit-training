package com.nama.springboot.firstdemo.model;

public class Employee {
	private String Empname;
	private int Empid;
	private String Address;
	private double sal;
	
	
	public Employee(String Empname,int Empid,String Address,double sal) {
		super();
		this.Empname=Empname;
		this.Empid=Empid;
		this.Address=Address;
		this.sal=sal;
			
	}

	public String getEmpname() {
		return Empname;
	}

	public void setEmpname(String empname) {
		Empname = empname;
	}

	public int getEmpid() {
		return Empid;
	}

	public void setEmpid(int empid) {
		Empid = empid;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public double getSal() {
		return sal;
	}

	@Override
	public String toString() {
		return "Employee [Empname=" + Empname + ", Empid=" + Empid + ", Address=" + Address + ", sal=" + sal + "]";
	}



	@Override
	public boolean equals(Object obj) {
		return  this.Empid == ((Employee)obj).Empid;
	}
	
	

	
	

}
