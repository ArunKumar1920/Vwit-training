package com.nama.springboot.firstdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.nama.springboot.firstdemo.model.Books;

@Configuration
@Profile("prod")
public class ProdConfiguration {
	
	@Autowired
	AppConfigprop prop;
	
	@Bean("book")
	public Books getBook() {
		return new Books(prop.getBook().getPrice(),prop.getBook().getName());
		
	}

}
