package com.nama.springboot.firstdemo.webcontroller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.nama.springboot.firstdemo.dao.EmployeeDao;
import com.nama.springboot.firstdemo.model.Employee;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeDao empDao;
	
	@GetMapping("/getemp/{Empid}")
	public String getEmpDetails(@PathVariable int Empid,ModelMap model) {
		Employee e = empDao.getEmp(Empid);
		if(e!=null) {
			model.addAttribute("empObj", e);
		}
		else {
			model.addAttribute("msg","employee not found with id: "+Empid);
		}
		return "Employee";
	}

}
