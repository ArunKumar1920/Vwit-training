package com.nama.springboot.firstdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.nama.springboot.firstdemo.model.Helloworld;

@Configuration
@Profile("dev")
public class DevConfiguration {
	
	@Autowired
	 AppConfigprop prop;
	
	@Bean("hello")
	public Helloworld getHello() {
		
		return new Helloworld(prop.getMessage());
	}

}
