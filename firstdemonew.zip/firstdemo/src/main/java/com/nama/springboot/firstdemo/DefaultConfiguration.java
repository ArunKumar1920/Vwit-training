package com.nama.springboot.firstdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.nama.springboot.firstdemo.model.Employee;

@Configuration
public class DefaultConfiguration {
	
	@Autowired
	AppConfigprop prop;
	
	
	@Bean("emp")
	public Employee getemp() {
		int id= prop.getEmp().getEmpid();
		String name=prop.getEmp().getEname();
		String Address=prop.getEmp().getAddress();
		double sal=prop.getEmp().getSal();
		
		return new Employee(name,id,Address,sal);
	}

}
