package com.nama.springboot.firstdemo.dao;

import java.util.ArrayList;
import java.util.List;


import org.springframework.stereotype.Service;
import com.nama.springboot.firstdemo.model.Employee;

@Service
public class EmployeeDao {
	
	List<Employee> Emparr;
	public EmployeeDao() {
		Emparr = new ArrayList<Employee>();
		
		Emparr.add(new Employee("hardik",101,"delhi",2000));
		Emparr.add(new Employee("virat",109,"mumbai",8000));
	    Emparr.add(new Employee("rohit",110,"goa",5000));
		
	}

	public boolean addEmp(Employee e)
	{
		return this.Emparr.add(e);
		
	}
	
	public Employee getEmp(int Empid)
	{
		
		 Employee emp = Emparr.stream().filter((e)->{ return
				 e.getEmpid()==Empid; }).findFirst().orElse(null);
		 
		 System.out.println(emp);
		 return emp;

}
	public boolean removeEmp(Employee e)
	{
		
		
		return this.Emparr.remove(e);
		
	}

	public boolean removeEmp1(int Empid)
	{
		
	  return this.Emparr.removeIf(e->e.getEmpid()==Empid);
		
		
	}
	
	
	public List<Employee> getAllEmp()
	{
		return this.Emparr;
	}

	}
