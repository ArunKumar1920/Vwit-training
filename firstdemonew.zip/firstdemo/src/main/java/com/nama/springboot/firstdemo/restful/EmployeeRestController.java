package com.nama.springboot.firstdemo.restful;
import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.nama.springboot.firstdemo.dao.BookDao;
import com.nama.springboot.firstdemo.dao.EmployeeDao;
import com.nama.springboot.firstdemo.exception.BookNotFoundException;
import com.nama.springboot.firstdemo.exception.EmpNotFoundException;
import com.nama.springboot.firstdemo.model.Book;
import com.nama.springboot.firstdemo.model.Employee;


@RestController
public class EmployeeRestController {
	
	@Autowired
	EmployeeDao empdao;
	
	@GetMapping("Employee/{Empid}")
	public Employee getEmp(@PathVariable int Empid) {
		Employee e = this.empdao.getEmp(Empid);

		if (e == null)
			throw new EmpNotFoundException("Employee with id:" + Empid + " not found");
		else
			return e;

	}
	@GetMapping("Employee1/{Empid}")
	public ResponseEntity getEmp1(@PathVariable int Empid) {
		Employee e = this.empdao.getEmp(Empid);

		if (e == null) {
			return ResponseEntity.notFound().build();
		} else {
			return ResponseEntity.ok(e.toString());
		}

	}
	@GetMapping("Employee2/{empid}")
	public ResponseEntity<Employee> getEmp2(@PathVariable int empid) {
		Employee e = this.empdao.getEmp(empid);

		if (e == null)
			return ResponseEntity.notFound().build();
		else
			return ResponseEntity.ok(e);

	}
	@PostMapping("addemp")
	public String addEmp(@RequestBody Employee e) {
		boolean r = this.empdao.addEmp(e);

		if (r) {
			return "employee with empkid:" + e.getEmpid() + " added successfully..";
		} else {
			return "Not able to add book with bookid:" + e.getEmpid();
		}

	}

	@PostMapping("addemp1")
	public ResponseEntity<Object> addEmp1(@RequestBody Employee e) {
		boolean r = this.empdao.addEmp(e);

		if (!r)
			return ResponseEntity.noContent().build();

		System.out.println(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

		System.out.println(ServletUriComponentsBuilder.fromCurrentContextPath().toUriString());

		URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/employee/{id}")
				.buildAndExpand(e.getEmpid()).toUri();

		/*
		 * URI location = ServletUriComponentsBuilder .fromCurrentRequest()
		 * .path("/{id}") .buildAndExpand(b.getBookId()) .toUri();
		 */
		return ResponseEntity.created(location).build();

	}

	@GetMapping("allemp")
	public List<Employee> getAllEmp() {
		return this.empdao.getAllEmp();
	}
	@DeleteMapping("rememp")
	public String removeEmp(@RequestBody Employee e) {
		boolean status = this.empdao.removeEmp(e);

		if (status) {
			return "Employee with empid:" + e.getEmpid() + " deleted successfully";
		} else {
			return "Not able to delete employee with empid:" + e.getEmpid();
		}

	}
	@DeleteMapping("rememp/{empid}")
	public String removeEmp(@PathVariable int Empid) {
		boolean status = this.empdao.removeEmp1(Empid);

		if (status) {
			return "employee with empid:" + Empid + " deleted successfully";
		} else {
			return "Not able to delete employee with empid:" + Empid;
		}
		}
	
	@DeleteMapping("rememp1/{empid}")
	public ResponseEntity<String> removeEmp1(@PathVariable int Empid) {
		boolean status = this.empdao.removeEmp1(Empid);

			if (status) {
				return ResponseEntity.ok("Employee removed with empid:" + Empid);
			} else {
				return ResponseEntity.notFound().build();
			}

	}


}
