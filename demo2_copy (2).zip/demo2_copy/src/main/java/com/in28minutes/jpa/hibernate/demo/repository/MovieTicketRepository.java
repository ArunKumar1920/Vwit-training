package com.in28minutes.jpa.hibernate.demo.repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.in28minutes.jpa.hibernate.demo.entity.MovieTicket;

@Repository
@Transactional
public class MovieTicketRepository {
	
	@Autowired
    EntityManager em;
	
	 public void insert(MovieTicket mt) {
	        
	        System.out.println("inside movieticket Repository insert method.."+mt);
	        em.persist(mt);
	        
	    }


}
