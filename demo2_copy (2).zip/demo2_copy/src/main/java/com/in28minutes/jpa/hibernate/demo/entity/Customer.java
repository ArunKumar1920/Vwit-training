package com.in28minutes.jpa.hibernate.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(nullable = false)
	private String name;
	
	
	@OneToOne
	@JoinColumn(name="ticket_id")
	private MovieTicket movieticket;
	
	public Customer() {
		
	}

	public Customer(String name,MovieTicket movieticket) {
		super();
		this.name = name;
		this.movieticket=movieticket;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

	public MovieTicket getMovieticket() {
		return movieticket;
	}

	public void setMovieticket(MovieTicket movieticket) {
		this.movieticket = movieticket;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", movieticket=" + movieticket + "]";
	}

	
	

}
