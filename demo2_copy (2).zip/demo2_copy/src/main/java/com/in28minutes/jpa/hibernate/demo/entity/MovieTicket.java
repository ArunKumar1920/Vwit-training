package com.in28minutes.jpa.hibernate.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="movieticket")
public class MovieTicket {
	
	
	@Id
	private int ticketid;
	
	@Column
	private String movieName;
	
	public MovieTicket() {
		
	}

	public MovieTicket(int ticketid, String movieName) {
		super();
		this.ticketid = ticketid;
		this.movieName = movieName;
	}

	public int getTicketid() {
		return ticketid;
	}

	public void setTicketid(int ticketid) {
		this.ticketid = ticketid;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	@Override
	public String toString() {
		return "MovieTicket [ticketid=" + ticketid + ", movieName=" + movieName + "]";
	}
	
	
	


}
