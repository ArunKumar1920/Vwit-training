package com.in28minutes.jpa.hibernate.demo.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Course {
	
	@Id
	private int courseId;
	
	@Column
	private String courseName;
	
//	@OneToMany(mappedBy="course")
//	private List<Employee> employees = new ArrayList<>();
	
	@ManyToMany
//	@JoinTable(name = "courses", joinColumns = @JoinColumn(name = "book_id"), inverseJoinColumns = @JoinColumn(name = "library_id"))
	private List<Employee> employees = new ArrayList<>();

	public Course() {
		super();
	}
	

	public Course(int courseId, String courseName) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setStudents(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + "]";
	}
	
	

}
