package com.nama.springboot.firstdemo.dao;

import org.springframework.stereotype.Service;

import com.nama.springboot.firstdemo.model.Employee;

import java.util.List;
import java.util.ArrayList;

@Service
public class EmpDao {
	List<Employee> emparr;
	
	public EmpDao() {
		emparr = new ArrayList<Employee>();
		emparr.add(new Employee("Vidit",12,"Delhi",25000));
		emparr.add(new Employee("Amar",15,"Mumbai",67000));
		emparr.add(new Employee("Suraj",10,"Bangalore",20000));
		emparr.add(new Employee("Gagan",22,"Delhi",34000));
		
	}
	
	public boolean addEmployee(Employee e) {
		return this.emparr.add(e);
		
	}
	
	public Employee getEmployee(int empid) {
		
		Employee employee = emparr.stream().filter((e)-> { return
				e.getEmpid() == empid;}).findFirst().orElse(null);
		System.out.println(employee);
		return employee;
		
		
	}
	
	public boolean removeEmployee(Employee e) {
		return this.emparr.remove(e);
	}

	public boolean removeEmployee1(int empid) {
		return this.emparr.removeIf(e->e.getEmpid()==empid);
	}
	
	public List<Employee> getAllEmployees() {
		
		return this.emparr;
	}
	
	

}
