package com.nama.springboot.firstdemo.restful;

import java.net.URI;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.nama.springboot.firstdemo.dao.EmpDao;
import com.nama.springboot.firstdemo.exception.EmployeeNotFoundException;
import com.nama.springboot.firstdemo.model.Employee;

@RestController
public class EmployeeRestController {
	
	@Autowired
	EmpDao empdao;
	
	@GetMapping("employee/{empid}")
	public Employee getEmployee(@PathVariable int empid) {
		Employee e = this.empdao.getEmployee(empid);
		
		if(e == null) {
			throw new EmployeeNotFoundException("Employee with " + empid + " not found");
		} else {
			return e;	
		}
	}
		
	
	@PostMapping("addEmployee1")
	public ResponseEntity<Object> addEmployee1(@RequestBody Employee e) {
		boolean rb = this.empdao.addEmployee(e);
		
		if(!rb) {
			return ResponseEntity.noContent().build();
		}
		
		System.out.println(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
		System.out.println(ServletUriComponentsBuilder.fromCurrentContextPath().toUriString());
		URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/employee/{id}").buildAndExpand(e.getEmpid()).toUri();
			
		return ResponseEntity.created(location).build();
	}
	
	@GetMapping("allemployees")
	public List<Employee> getAllEmployees() {
		return this.empdao.getAllEmployees();
	}
	
	
	
	@DeleteMapping("remEmployee1/{empid}")
	public ResponseEntity<String> removeEmployee1(@PathVariable int empid) {
		boolean status = this.empdao.removeEmployee1(empid);
		
		if(status) {
			return ResponseEntity.ok("Employee removed with employee id:" + empid);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
}
	
		
