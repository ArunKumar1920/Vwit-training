package com.nama.springboot.firstdemo.webcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nama.springboot.firstdemo.dao.EmpDao;
import com.nama.springboot.firstdemo.model.Employee;

@Controller
public class EmployeeController {
	
	@Autowired
	EmpDao empDao;
	
	@GetMapping("/getEmployee/{empid}")
	public String getEmployeeDetails(@PathVariable int empid,ModelMap model) {
		Employee e = empDao.getEmployee(empid);
		model.addAttribute("empObj", e);
		if(e != null) {
			model.addAttribute("empobj",e);
		
	} else {
		model.addAttribute("msg","Employee Not found with id" + empid);
		
	}
		return "emp";
}
}

