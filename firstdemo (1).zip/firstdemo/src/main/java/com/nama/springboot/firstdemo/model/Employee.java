package com.nama.springboot.firstdemo.model;

public class Employee {
	
	private String empname;
	private int empid;
	private String add;
	private double salary;
	
	public Employee() {
		System.out.println("Employee bean created");
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Employee(String empname, int empid, String add, double salary) {
		super();
		this.empname = empname;
		this.empid = empid;
		this.add = add;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empname=" + empname + ", empid=" + empid + ", add=" + add + ", salary=" + salary + "]";
	}
	
    @Override
	public boolean equals(Object obj1) {
		return this.empid == ((Employee)obj1).empid;
	}
	
	

}
